=begin
#-------------------------------------------------------------------------------------------------------------------------------------------------
#*************************************************************************************************
# Designed by Fredo6 - Copyright November 2008

# Permission to use this software for any purpose and without fee is hereby granted
# Distribution of this software for commercial purpose is subject to:
#  - the expressed, written consent of the author
#  - the inclusion of the present copyright notice in all copies.

# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#-----------------------------------------------------------------------------
# Name			:   FreeScale_Common.rb
# Original Date	:   8 Mar 2009 - version 2.0
# Description	:   Common environment for FreeScale
#-------------------------------------------------------------------------------------------------------------------------------------------------
#*************************************************************************************************
=end

module FreeScale

#---------------------------------------------------------------------------------------------------------------------------
# Overall Configuration for the Tools	
#---------------------------------------------------------------------------------------------------------------------------

# SCALE tool
CONFIG_Scale = {
	'Name' => "Scaling",
	'Supported' => 'BT',
	'Color' => ['Yellow', 'DarkRed'],
	'Visible' => 'B'
	}

# TAPER tool
CONFIG_Taper = {
	'Name' => "Tapering",
	'Supported' => 'BT',
	'Color' => ['Green', 'DarkMagenta'],
	'Visible' => 'B'
	}

# PLANAR SHEAR tool
CONFIG_PlanarShear = {
	'Name' => "Planar Shearing",
	'Supported' => 'BTA',
	'Color' => ['DarkGreen', 'Magenta'],
	'Visible' => 'BA'
	}

# ROTATE tool
CONFIG_Rotate = {
	'Name' => "Rotation",
	'Supported' => 'BA',
	'Color' => ['LightBlue'],
	'Visible' => 'BA'
	}

# STRETCH tool
CONFIG_Stretch = {
	'Name' => "Stretching",
	'Supported' => 'BT',
	'Color' => ['GreenYellow', 'DarkOliveGreen'],
	'Visible' => 'B'
	}

# TWIST tool
CONFIG_Twist = {
	'Name' => "Twisting",
	'Supported' => 'B',
	'Color' => ['Red'],
	'parent' => 'Rotate',
	'Visible' => 'B'
	}

# Radial Bending tool
CONFIG_RadialBend = {
	'Name' => "Radial Bending",
	'Supported' => 'A',
	'Color' => ['LightGreen'],
	'Visible' => 'A'
	}

# Make Unique tool
CONFIG_MakeUnique = {
	'Name' => "Make Unique",
	'Supported' => 'U',
	'Color' => ['LightGreen'],
	'Tooltip' => :TIP_Make_Unique,
	'Visible' => 'U'
	}

# Declaring the configuration - List and setting the titles
ALL_CONFIG = [:Scale, :Taper, :PlanarShear, :Stretch, :Twist, :Rotate, :RadialBend, :MakeUnique]

ALL_CONFIG.each { |symb| eval "T6[:NAME_#{symb.to_s}] = CONFIG_#{symb.to_s}['Name']" }

MENU_PERSO = [:T_MenuTools_Fredo6Collection, "Tools", :T_MenuPlugins_Fredo6Collection, "Plugins"]

#---------------------------------------------------------------------------------------------------------------------------
#Constants for FreeScale Module (do not translate here, use Translation Dialog Box instead)	
#---------------------------------------------------------------------------------------------------------------------------

# Dynamic strings for Tools menus and titles
T6[:MNU_Box] = "Box %1"
T6[:MNU_BoxTarget] = "Box %1 to Target"
T6[:MNU_Alone] = "%1 (Free)"
T6[:TIP_Box] = "%1 with orientation of scaling box"
T6[:TIP_BoxTarget] = "%1 with box by matching an origin and a target"
T6[:TIP_Angle] = "%1 by selection of plane and angle"
T6[:DEF_ColorBox] = "Box Color (%1)"

# Strings for the application
T6[:MSG_Status_Grip] = "Select a grip and Click"
T6[:MSG_Status_Drag] = "Drag grip to scale - CTRL for About Center - SHIFT for Non-Uniform scaling"
T6[:TIP_Edge] = "Click on Edge to orientate the deformation box"
T6[:TIP_Face] = "Click on Face to orientate the deformation box"
T6[:TIP_FromCenter] = "Scaling from Center"
T6[:TIP_UFromCenter] = "Uniform from Center"
T6[:TIP_Opposite] = "From Opposite point"
T6[:TIP_UOpposite] = "Uniform from Opposite point"
T6[:TIP_ClickExit] = "Click to Exit"
T6[:TIP_PostValidate] = "Click to validate deformation and reset box"
T6[:TIP_ScalingBox] = "Scaling Box"

T6[:TIP_Make_Unique] = "Make Groups and Components Unique"
T6[:DLG_Unique_Already] = "All components and groups are already unique"
T6[:DLG_Unique_InfoDlg] = "Make Unique Groups = %1 Components = %2"

T6[:STR_DimFromTo] = "from %1 to"

T6[:MNU_SwitchToTarget] = "Switch to Target mode (Double-Click on handle)"
T6[:MNU_SwitchToBox] = "Switch to Box mode (Double-Click on handle)"
T6[:MNU_AskDimensions] = "Enter New Dimensions (TAB)"
T6[:MNU_FreeScaling] = "%1: Free Scaling (SHIFT)"
T6[:MNU_UniformScaling] = "%1: Uniform Scaling (SHIFT)"
T6[:MNU_FromCenter] = "From Center (CTRL)"
T6[:MNU_FromOpposite] = "From Opposite point (CTRL)"
T6[:MNU_Done] = "Finish dragging"
T6[:MNU_Validate] = "Validate deformation and reset box"
T6[:MNU_Exit] = "Exit (click outside box)"
T6[:MNU_DividerDefault] = "Reset Divider to centre (Double Click)"
T6[:MNU_DividerShowHide] = "Show / Hide Divider (Stretch)"
T6[:MNU_NoDeform] = "Interactive deformation"
T6[:MNU_Wireframe] = "Wireframe simulation"
T6[:MNU_ActivateDice] = "Slicing"
T6[:MNU_DiceParam] = "Slicing Parameters (TAB)"

T6[:OPT_ShowDivider_No] = "Hidden"
T6[:OPT_ShowDivider_Grid] = "Grid"
T6[:OPT_ShowDivider_Rect] = "Rectangle"
OPT_ShowDivider = [['0', :OPT_ShowDivider_No], ['G', :OPT_ShowDivider_Grid], ['R', :OPT_ShowDivider_Rect]]

T6[:DLG_Dim_title] = "New Dimensions" 
T6[:WARNING_SelHandleFirst] = "You must select box handles first" 

#Colors and marks used by the Scale Tool
COLOR_Pk_Edge = "orange"
COLOR_Sel_Handle_Free = "white"
COLOR_Sel_Handle_FreeTarget = "lightgrey"
COLOR_Sel_Handle_Pivot = "red"
COLOR_Free_LineTarget = "purple"
MARK_Target_Origin = [16, 4, "darkgreen"]
MARK_Target_Target = [16, 4, "darkred"]
MARK_Free_Target = [4, 2, "orange"]
MARK_Divider_Origin = [7, 3, "black"]
MARK_Divider_Target = [7, 3, "darkred"]

LIMIT_InferenceScale = 0.05		#Delta for scale inference at round numbers
LIMIT_SmallScale = 0.1			#Do not go below this scale ratio when dragging

#Labels for Default Parameters
T6[:DEFAULT_SectionAll] = "Active Options at start up"
T6[:DEFAULT_SelectionExtended] = "When started, Extend selection to all connected entities"
T6[:DEFAULT_Flag_LiveDeform] = "Use Live Deformation by default (when applicable)"
T6[:DEFAULT_Key_LiveDeform] = "Toggle Live Deformation"
T6[:DEFAULT_Flag_Wireframe] = "Use Wireframe by default"
T6[:DEFAULT_Color_Wireframe] = "Color of the Wireframe"
T6[:DEFAULT_Key_Wireframe] = "Toggle Wireframe"
T6[:DEFAULT_Flag_ShowDivider] = "Stretch Divider visibility by default"
T6[:DEFAULT_Key_ShowDivider] = "Toggle Show / Hide Divider (Stretch)"
T6[:DEFAULT_Flag_ActivateDice] = "Slicing active by default"
T6[:DEFAULT_Key_ActivateDice] = "Toggle Activation Slicing"
T6[:DEFAULT_Flag_EdgeNewProp] = "Default Properties for newly created edges"
T6[:DEFAULT_Key_EdgeNewProp] = "Dialog box for Properties for newly created edges"
T6[:DEFAULT_WidthBox] = "Width of the Deformation Box (pixel)"
T6[:DEFAULT_SectionColorBox] = "Parameters for the Deformation Box"

Chrono = Traductor::Chrono6
Trace = Traductor::Tracer6

#--------------------------------------------------------------------------------------------------------------
# Plugin Startup Method
#--------------------------------------------------------------------------------------------------------------			 

def FreeScale.startup

	#Common Default Parameters
	MYDEFPARAM.separator :DEFAULT_SectionAll
	MYDEFPARAM.declare :DEFAULT_SelectionExtended, true, 'B'
	MYDEFPARAM.declare :DEFAULT_Flag_LiveDeform, true, 'B'
	MYDEFPARAM.declare :DEFAULT_Color_Wireframe, "Purple", 'K'
	MYDEFPARAM.declare :DEFAULT_Flag_Wireframe, true, 'B'
	MYDEFPARAM.declare :DEFAULT_Flag_ShowDivider, '0', 'H', T6[OPT_ShowDivider]
	MYDEFPARAM.declare :DEFAULT_Flag_ActivateDice, false, 'B'
	MYDEFPARAM.declare :DEFAULT_Flag_EdgeNewProp, 'S;;M', 'M', [['S', 'Soft'], ['M', 'Smooth'], ['H', 'Hidden']]
	
	#function keys
	fkeys = Traductor::FKeyOption.fkeys
	MYDEFPARAM.separator :T_DEFAULT_SectionFunctionKey
	MYDEFPARAM.declare :DEFAULT_Key_LiveDeform, 'F2', 'H', fkeys
	MYDEFPARAM.declare :DEFAULT_Key_Wireframe, 'F3', 'H', fkeys
	MYDEFPARAM.declare :DEFAULT_Key_ShowDivider, 'F4', 'H', fkeys
	MYDEFPARAM.declare :DEFAULT_Key_ActivateDice, 'F4', 'H', fkeys
	MYDEFPARAM.declare :DEFAULT_Key_EdgeNewProp, 'F5', 'H', fkeys
	
	# All menus and icons
	FreeScale.configure
			
	#Startup of the Plugin
	MYPLUGIN.go
end

#--------------------------------------------------------------------------------------------------------------
# Configuartion and Utilities Method at module level
#--------------------------------------------------------------------------------------------------------------			 				   

#Configuring all tools, based on naming conventions strictly followed
def FreeScale.configure
	lst_visible = []
	sepa = false
	
	#Default menu configuration
	MYPLUGIN.declare_topmenu nil, MENU_PERSO
	tc = Traductor::TestCondition.new() { FreeScale.valid_selection? }
	submenu = MYPLUGIN.plugin_name
	MYDEFPARAM.separator :DEFAULT_SectionColorBox	
	MYDEFPARAM.declare :DEFAULT_WidthBox, 3, 'I:>=2<=9'
	
	#Configuring each tool
	ALL_CONFIG.each do |symb|
		begin
			#retrieving the hash table with configuration parameter
			code = symb.to_s
			hconfig = FreeScale.const_get 'CONFIG_' + code
			stitle = 'NAME_' + code
			name = T6[stitle.intern]
			supported = hconfig['Supported']
			visible = hconfig['Visible']
			lcolors = hconfig['Color']
			if (lcolors.class == Array)
				bcolor = lcolors[0]
				tcolor = lcolors[1]
			elsif lcolors.class == String
				bcolor = lcolors
			end	
			bcolor = 'Black' unless bcolor
			tcolor = 'Red' unless tcolor
			
			#separator toolbar
			if visible
				MYPLUGIN.declare_separator if sepa
				sepa = true
			end	
					
			#Box tool	
			if supported =~ /B/i
				cmd = "FSC_#{code}_Command"
				scmd = cmd.intern
				menu = T6[:MNU_Box, name]
				ttip = T6[:TIP_Box, name]
				icon = code
				scol = "DEFAULT_Color_Box#{icon}"
				txcol = T6[:DEF_ColorBox, menu]
				MYDEFPARAM.declare scol.intern, bcolor, 'K', nil, txcol
				MYPLUGIN.declare_command_long(scmd, menu, ttip, icon) { FreeScale.launch code }
				MYPLUGIN.declare_context_handler_long(scmd, menu, ttip, tc, nil, submenu) { FreeScale.launch code }
				lst_visible.push scmd if visible =~ /B/i
			end	
		
			#Target mode
			if supported =~ /T/i
				cmd = "FSC_#{code}_TARGET_Command"
				scmd = cmd.intern
				menu = T6[:MNU_BoxTarget, name]
				ttip = T6[:TIP_BoxTarget, name]
				icon = code + "Target"
				txcol = T6[:DEF_ColorBox, menu]
				scol = "DEFAULT_Color_Box#{icon}"
				MYDEFPARAM.declare scol.intern, tcolor, 'K', nil, txcol
				MYPLUGIN.declare_command_long(scmd, menu, ttip, icon) { FreeScale.launch code, 'T' }
				MYPLUGIN.declare_context_handler_long(scmd, menu, ttip, tc, nil, submenu) { FreeScale.launch code, 'T' }
				lst_visible.push scmd if visible =~ /T/i
			end
			
			#Standalone mode
			if supported =~ /A/i
				cmd = "FSC_#{code}_ALONE_Command"
				scmd = cmd.intern
				menu = T6[:MNU_Alone, name]
				sttip = hconfig['Tooltip']
				ttip = (sttip) ? T6[sttip] : T6[:TIP_Angle, name]
				icon = code + "_Alone"
				MYPLUGIN.declare_command_long(scmd, menu, ttip, icon) { FreeScale.launch code, 'A' }
				MYPLUGIN.declare_context_handler_long(scmd, menu, ttip, tc, nil, submenu) { FreeScale.launch code, 'A' }
				lst_visible.push scmd if visible =~ /A/i
			end

			#Standalone mode
			if supported =~ /U/i
				cmd = "FSC_#{code}_UTIL_Command"
				scmd = cmd.intern
				menu = name
				sttip = hconfig['Tooltip']
				ttip = (sttip) ? T6[sttip] : T6[:TIP_Angle, name]
				icon = code + "_Util"
				MYPLUGIN.declare_command_long(scmd, menu, ttip, icon) { FreeScale.launch code, 'U' }
				MYPLUGIN.declare_context_handler_long(scmd, menu, ttip, tc, nil, submenu) { FreeScale.launch code, 'U' }
				lst_visible.push scmd if visible =~ /U/i
			end
			
		#End of protected section	
		rescue
		end	
	end	
	
	#declaring the items visible
	MYPLUGIN.default_icons_visible lst_visible
	MYPLUGIN.default_handlers_visible lst_visible	
end

# Check if the proposed selection is valid for FreeSacle deformations
def FreeScale.valid_selection?
	lclass = [Sketchup::Face, Sketchup::Edge, Sketchup::Group, Sketchup::ComponentInstance]
	Sketchup.active_model.selection.each { |e| return true if lclass.include?(e.class) }
	false
end
	
def FreeScale.calculate_title(code, mode)
	sname = "NAME_#{code}"
	name = T6[sname.intern]
	if mode =~ /U/i
		title = name
	elsif mode =~ /A/i
		title = T6[:MNU_Alone, name]
	elsif mode =~ /T/i
		title = T6[:MNU_BoxTarget, name]
	else
		title = T6[:MNU_Box, name]
	end
	title	
end
	
# Return the title of thecurrent tool	
def FreeScale.compute_title_tool(hparam)
	mode = (hparam['Mode_Target']) ? 'T' : hparam['ToolMode']
	FreeScale.calculate_title hparam['ToolType'], mode
end

# Return the cursor object id for the current tool
def FreeScale.get_cursor(hparam)
	mode = (hparam['Mode_Target']) ? 'T' : hparam['ToolMode']
	if mode == 'U'
		hparam["Cursor_" + hparam["OriginalToolType"] + '_Util']
	elsif mode == 'A'
		hparam["Cursor_" + hparam["OriginalToolType"] + '_Alone']
	else	
		hparam["Cursor_" + hparam["OriginalToolType"] + ((hparam["Mode_Target"]) ? 'Target' : '')]
	end	
end

#--------------------------------------------------------------------------------------------------------------
# Top Calling functions: create the classes and launch the tools
#--------------------------------------------------------------------------------------------------------------			 				   

def FreeScale.launch(tooltype, mode=nil)
	
	#Creating the context
	hparam = {}
	hparam["ToolType"] = tooltype
	hparam["ToolMode"] = mode
	hparam["OriginalToolType"] = tooltype
	hparam["Title"] = FreeScale.calculate_title tooltype, mode
	
	# Mode Alone
	if mode =~ /A/i
		hparam["Mode_Alone"] = true
		sclass = tooltype + '_AloneTool'
		lstcursors = [tooltype + '_Alone']

	#Utility tools	
	elsif mode =~ /U/i
		hparam["Mode_Util"] = true
		sclass = tooltype + '_UtilTool'
		lstcursors = [tooltype + '_Util']
		
	#Mode box	
	else
		hparam["Mode_Target"] = true if mode =~ /T/i
		sclass = tooltype + 'Tool'
		lstcursors = [tooltype, tooltype + 'Target']
		lstcursors += ['Scale', 'ScaleTarget'] unless tooltype =~ /Scale/i
		["None", "Arrow", "Arrow_Edge", "Arrow_Face", "Arrow_Exit"].each do |name| 
			hparam['Cursor_' + name] = MYPLUGIN.create_cursor(name, 0, 0)
		end	
		["Validate"].each do |name| 
			hparam['Cursor_' + name] = MYPLUGIN.create_cursor(name, 12, 23)
		end	
	end	

	#Creating an instance of the main class
	begin
		hparam["MainTool"] = eval sclass + '.new hparam'
	#rescue
		#UI.messagebox "Class #{sclass} is not implemented or in error"
		#return nil
	end	
	
	#Creating the required cursors
	lstcursors.each do |name| 
		hparam['Cursor_' + name] = MYPLUGIN.create_cursor(name, 1, 3)
	end	
	
	#Creating the Selection and Scale Tools 
	seltool = SelectionTool.new hparam
	hparam["SelectTool"] = seltool
		
	#Starting with the selection tool
	seltool._select
end
	
#--------------------------------------------------------------------------------------------------------------
# Selection Tool for picking up entities
#   < Specific implementation over the generic class Traductor::StandardSelectionTool
#--------------------------------------------------------------------------------------------------------------			 				   

class SelectionTool

@@extend_selection = nil

def initialize(hparam)
	@hparam = hparam
	@tool = Traductor::StandardSelectionTool.new self, hparam
	@@extend_selection = MYDEFPARAM[:DEFAULT_SelectionExtended] if @@extend_selection == nil
	@tool.extend_selection = @@extend_selection
	@tool.extend_face = true
	@title_tool = FreeScale.compute_title_tool @hparam
end

#Selection and activation of the tool
def _select
	Sketchup.active_model.select_tool @tool
end
		
def sub_cursor_set(entity, extend_selection)
	FreeScale.get_cursor @hparam
end

def sub_exit_tool
	@@extend_selection = @tool.extend_selection
	@hparam["MainTool"]._select
end

def sub_deactivate(view)
	@@extend_selection = @tool.extend_selection
end

def sub_check_entity(entity)
	case entity.typename
	when "Face", "Edge", "Group", "ComponentInstance", "ConstructionPoint"
		return true
	end
	false
end

#Get the title of the tool
def sub_get_title_tool
	FreeScale.compute_title_tool @hparam
end

end	#class SelectionTool

#--------------------------------------------------------------------------------------------------------------
# Common class Implementation for Picking  tools  
#--------------------------------------------------------------------------------------------------------------			 				   
	
class AllPickTool

#Selection and activation of the tool
def _select
	Sketchup.active_model.select_tool @tool
end

#Simulate a move
def onMouseMove_zero
	@tool.onMouseMove_zero
end

#Get the title of the tool
def sub_get_title_tool
	FreeScale.compute_title_tool @hparam
end

def sub_resume(view)
	@scaletool.resume view
end

def sub_onKeyDown(key, rpt, flags, view)
	#Function keys
	return true if @scaletool.check_function_key(key, rpt, flags, view)
	
	#Ctrl key - Center vs. Opposite
	if key == COPY_MODIFIER_KEY
		@scaletool.onKeyDown(key, rpt, flags, view)
		return true
	end	
	false
end

def sub_onKeyUp(key, rpt, flags, view)
	#Parameters
	if key == 9
		@scaletool.onKeyUp(key, rpt, flags, view)
		return true
	end	
	false
end

def sub_cursor_set
	@idcursor
end

def sub_getMenu_before(menu)
	@scaletool.common_menu menu
	false
end

end	#class AllPickTool
	
#--------------------------------------------------------------------------------------------------------------
# Tool for picking 2 points (Origin and Target)
#   < Specific implementation over the generic class Traductor::StandardPickLineTool
#--------------------------------------------------------------------------------------------------------------			 				   

class PickLineTool < AllPickTool

#Placeholder subclassing routines
def initialize(hparam)
	@hparam = hparam
	@tool = Traductor::StandardPickLineTool.new self, hparam
	@tool.set_mark_origin MARK_Target_Origin, 2, ""
	@tool.set_mark_target MARK_Target_Target, 2, ""
	@scaletool = hparam["MainTool"]
	refresh_hsh_entityID
	@idcursor = 0
end

def set_custom_axes(axes, tooltip=nil)
	@tool.set_custom_axes axes, tooltip
end

def sub_draw_before(view, pt_origin, pt_target)
	@scaletool.draw view
end

def sub_move(view, pt_origin, pt_target)
	return @scaletool.reach_target(view, pt_origin, pt_target) if pt_target
end

def refresh_hsh_entityID
	@tool.set_hsh_entityID @scaletool.get_hsh_entityID
end

def sub_onCancel(flag, view)
	@scaletool.onCancel flag, view
end

def sub_exit_tool 
	@scaletool._select
end	

def sub_getMenu_after(menu)
	menu.add_separator
	menu.add_item(T6[:MNU_SwitchToBox]) { @scaletool.return_from_target }
end

def sub_onLButtonDoubleClick(flags, x, y, view, state)
	return unless state <= 1
	@scaletool.return_from_target
end

def sub_execute(pt_origin, pt_target)
	@scaletool.execute_from_target
end

def sub_test_origin(pt_origin)
	pt = @scaletool.test_origin pt_origin
end

end	#class PickLineTool

#--------------------------------------------------------------------------------------------------------------
# Tool for picking an angle via the protractor
#   < Specific implementation over the generic class Traductor::StandardProtractorTool
#--------------------------------------------------------------------------------------------------------------			 				   

class PickAngleTool < AllPickTool

#Placeholder subclassing routines
def initialize(hparam, origin, normal, basedir=nil)
	@hparam = hparam
	@tool = Traductor::StandardProtractorTool.new self, hparam
	@tool.impose_direction origin, normal, basedir
	@scaletool = hparam["MainTool"]
	refresh_hsh_entityID
	@id_cursor = FreeScale.get_cursor hparam
end

def set_custom_axes(axes, tooltip=nil)
	@tool.set_custom_axes axes, tooltip
end

def refresh_hsh_entityID
	@tool.set_hsh_entityID @scaletool.get_hsh_entityID
end

def sub_draw_before(view, state)
	@scaletool.draw view
end

def sub_execute(origin, normal, basedir, angle) 
	@scaletool.execute_from_protractor origin, normal, basedir, angle
end

def sub_rotate(view, origin, normal, basedir, angle) 
	@scaletool.rotate_from_protractor view, origin, normal, basedir, angle
end

def sub_onCancel(flag, view, state)
	@scaletool.onCancel flag, view
	sub_exit_tool if state >= 1
end

def sub_exit_tool 
	@scaletool._select
end	
	
end	#class PickAngleTool

#--------------------------------------------------------------------------------------------------------------
# Tool for moving a divider (for Stretching)
#   < Specific implementation over the generic class Traductor::StandardPickLineTool
#--------------------------------------------------------------------------------------------------------------			 				   

class PickDividerTool < AllPickTool

#Placeholder subclassing routines
def initialize(hparam, origin, axes, iaxe)
	@hparam = hparam
	@origin = origin
	@axes = axes
	@iaxe = iaxe
	@tool = Traductor::StandardPickLineTool.new self, hparam
	@tool.set_mark_origin nil
	@tool.set_mark_target MARK_Divider_Target, 2, ""
	@scaletool = hparam["MainTool"]
	@idcursor = 0
end

def sub_activate
	@tool.set_custom_axes @axes, T6[:TIP_ScalingBox]
	@tool.set_origin @origin
	@tool.lock_axis ['X', 'Y', 'Z'][@iaxe]
	@tool.set_line_style 1, '-'
end

def sub_draw_before(view, pt_origin, pt_target)
	@scaletool.draw view
end

def sub_move(view, pt_origin, pt_target)
	true
end

def sub_onCancel(flag, view)
	@scaletool.compute_divider_factor @origin
end

def sub_exit_tool 
	@scaletool._select
end	

def sub_onLButtonDoubleClick(flags, x, y, view, state)
	return unless state <= 1
	@scaletool.reset_divider_to_centre
end

def put_divider_to_centre
	@scaletool.compute_divider_factor nil
	sub_exit_tool
end

def sub_execute(pt_origin, pt_target)
	@scaletool.validate_scaling true
	sub_exit_tool
end

def sub_test_target(pt_target)
	@scaletool.compute_divider_factor pt_target
end

end	#class PickDividerTool

end	#End Module FreeScale
