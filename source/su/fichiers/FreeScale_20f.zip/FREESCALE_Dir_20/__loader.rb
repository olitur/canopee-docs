Traductor::Plugin.myplugin('FreeScale').effective_load
