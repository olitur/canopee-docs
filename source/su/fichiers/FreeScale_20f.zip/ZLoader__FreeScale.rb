=begin
#-------------------------------------------------------------------------------------------------------------------------------------------------
#*************************************************************************************************
# Designed November 2008 by Fredo6

# Permission to use this software for any purpose and without fee is hereby granted
# Distribution of this software for commercial purpose is subject to:
#  - the expressed, written consent of the author
#  - the inclusion of the present copyright notice in all copies.

# THIS SOFTWARE IS PROVIDED "AS IS" AND WITHOUT ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
#-----------------------------------------------------------------------------
# Name			:   Zloader__FreeScale.rb
# Original Date	:   8 Mar 2008 - version 2.0
# Description	:   Register the FreeScale tool as a LibFredo6 Plugin
#-------------------------------------------------------------------------------------------------------------------------------------------------
#*************************************************************************************************
=end

require 'LibFredo6.rb'

LibFredo6.register_plugin "FreeScale", "FREESCALE_Dir_20"
