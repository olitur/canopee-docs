$GH1001bit_path="C:/Program Files/Google/Google SketchUp 7/Plugins/1001bit"
