$GH1001bit_path="/Library/Application Support/Google Sketchup 6/SketchUp/plugins/1001bit"
