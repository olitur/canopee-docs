require 'sketchup.rb'

t = Sketchup.load $GH1001bit_path + "/1001bitmenu"
puts "loading 1001bitmenu >> #{t}"
