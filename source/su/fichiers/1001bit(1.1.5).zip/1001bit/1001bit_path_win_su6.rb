$GH1001bit_path="C:/Program Files/Google/Google SketchUp 6/Plugins/1001bit"
